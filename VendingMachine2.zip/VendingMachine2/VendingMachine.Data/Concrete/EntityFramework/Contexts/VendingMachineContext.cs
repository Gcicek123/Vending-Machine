﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using VendingMachine.Domain.Concrete.Products;

namespace VendingMachine.Data.Concrete.EntityFramework.Contexts
{
    public class VendingMachineContext : DbContext
    {
        public DbSet<Food> Foods { get; set; }
        public DbSet<Drink> Drinks { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server = PARTTIME02-PC; Database = ProgrammersBlog; Trusted_Connection = True; Connect Timeout = 30; MultipleActiveResultSets = True; ");

        }
    }

    
}
