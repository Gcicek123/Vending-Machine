﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;
using VendingMachine.Domain.Concrete.Products;
using VendingMachine.Domain.Concrete.Slots;

namespace VendingMachine.Data.Concrete.EntityFramework.AggregatesModel
{
    public class FoodConfiguration : IEntityTypeConfiguration<Food>
    {
        public void Configure(EntityTypeBuilder<Food> builder)
        {
            builder.ToTable("Foods");

            builder.HasKey(a => a.Id);
            builder.Property(a => a.Id).ValueGeneratedOnAdd();
            builder.Property(a => a.Id).IsRequired();
            builder.Property(a => a.Id).HasMaxLength(2);
            builder.Property(a => a.Price).IsRequired();
            builder.Property(a => a.Price).HasMaxLength(2);
            builder.Property(a => a.Price).HasColumnType("INT");
            builder.Property(a => a.Quantity).IsRequired();
            builder.Property(a => a.Quantity).HasMaxLength(2);
            builder.Property(a => a.Quantity).HasColumnType("INT");
            builder.Property(a => a.Name).IsRequired();
            builder.Property(a => a.Name).HasMaxLength(20);
            builder.Property(a => a.Name).HasColumnType("NCHAR");
            builder.Property(a => a.CreatedDate).IsRequired();
            builder.Property(a => a.ModifiedDate).IsRequired();
            builder.Property(a => a.IsDeleted).IsRequired();
        }
    }
}
