﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;
using VendingMachine.Domain.Concrete.Slots;

namespace VendingMachine.Data.Concrete.EntityFramework.AggregatesModel
{
    public class SlotConfiguration : IEntityTypeConfiguration<Slot>
    {
        public void Configure(EntityTypeBuilder<Slot> builder)
        {
            builder.ToTable("Slots");

            builder.HasKey(a => a.Id);
            builder.Property(a => a.Id).ValueGeneratedOnAdd();
            builder.Property(a => a.Id).IsRequired();
            builder.Property(a => a.Id).HasMaxLength(2);
            builder.Property(a => a.CreatedDate).IsRequired();
            builder.Property(a => a.ModifiedDate).IsRequired();
            builder.Property(a => a.IsDeleted).IsRequired();
            builder.Property(a => a.IsEmpty).IsRequired();

            builder.HasOne(a => a.Drink).WithOne(a => a.Slot).HasForeignKey<Slot>(a => a.DrinkId); //tek tarafta yeterli
            builder.HasOne(a => a.Food).WithOne(a => a.Slot).HasForeignKey<Slot>(a => a.FoodId);
        }
    }
}
