﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using VendingMachine.Data.Abstract;
using VendingMachine.Data.Concrete.EntityFramework.Contexts;
using VendingMachine.Data.Concrete.EntityFramework.Repositories;

namespace VendingMachine.Data.Concrete
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly VendingMachineContext _context;
        private EfDrinkRepository _drinkRepository;
        private EfFoodRepository _foodRepository;
        private EfSlotRepository _slotRepository;

        public UnitOfWork(VendingMachineContext context)
        {
            _context = context;
        }

        public IDrinkRepository Drinks => _drinkRepository ?? new EfDrinkRepository(_context);

        public IFoodRepository Foods => _foodRepository ?? new EfFoodRepository(_context);

        public ISlotRepository Slots => _slotRepository ?? new EfSlotRepository(_context);

        public async ValueTask DisposeAsync()
        {
            await _context.DisposeAsync();
        }

        public async Task<int> SaveAsync()
        {
            return await _context.SaveChangesAsync();
        }
    }
}
