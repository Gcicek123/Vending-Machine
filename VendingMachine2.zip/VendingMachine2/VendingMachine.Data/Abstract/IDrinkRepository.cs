﻿using System;
using System.Collections.Generic;
using System.Text;
using VendingMachine.Core.Data.Abstract;
using VendingMachine.Domain.Concrete.Products;

namespace VendingMachine.Data.Abstract
{
    public interface IDrinkRepository : IRepository<Drink>
    {
    }
}
