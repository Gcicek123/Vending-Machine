﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VendingMachine.Core.Entities.Concrete
{
    public abstract class ProductBase : EntityBase
    {
        public virtual int Price { get; set; }
        public virtual int Quantity { get; set; }
        public virtual string Name { get; set; }

    }
}
