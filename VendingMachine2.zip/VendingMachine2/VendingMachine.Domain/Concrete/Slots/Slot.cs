﻿using System;
using System.Collections.Generic;
using System.Text;
using VendingMachine.Core.Entities.Abstract;
using VendingMachine.Core.Entities.Concrete;
using VendingMachine.Domain.Concrete.Products;

namespace VendingMachine.Domain.Concrete.Slots
{
    public class Slot : EntityBase, IEntity
    {

        public virtual bool IsEmpty { get; set; } = true;
        public long DrinkId { get; set; }
        public Drink Drink { get; set; }
        public long FoodId { get; set; }
        public Food Food { get; set; }

    }
}
