﻿using System;
using System.Collections.Generic;
using System.Text;
using VendingMachine.Core.Entities.Abstract;
using VendingMachine.Core.Entities.Concrete;
using VendingMachine.Domain.Concrete.Slots;

namespace VendingMachine.Domain.Concrete.Products
{
    public class Drink : ProductBase, IEntity
    {
        public virtual int ML { get; set; } = 0;
        public Slot Slot { get; set; }



        //EF
        /*public DrinkEntity()
        {

        }

        public DrinkEntity(int mL)
        {
            ML = mL;
        }

        public void SetML(int ml)
        {
            ML = ml;
        }

        public void Update(int ml)
        {
            ML = ml;
        }*/
    }
}
