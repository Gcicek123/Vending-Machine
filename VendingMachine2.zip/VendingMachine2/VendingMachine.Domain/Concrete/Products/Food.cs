﻿using System;
using System.Collections.Generic;
using System.Text;
using VendingMachine.Core.Entities.Abstract;
using VendingMachine.Core.Entities.Concrete;
using VendingMachine.Domain.Concrete.Slots;

namespace VendingMachine.Domain.Concrete.Products
{
    public class Food : ProductBase, IEntity
    {
        public virtual int Weight { get; set; } = 0;
        public virtual bool GlutenFree { get; set; } = false;
        public ICollection<Slot> Slots { get; set; }

        public Slot Slot { get; set; }
    }
}
