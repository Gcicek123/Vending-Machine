﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VendingMachine.Core.Entities.Abstract
{
    public interface IEntity
    {
    }
}
