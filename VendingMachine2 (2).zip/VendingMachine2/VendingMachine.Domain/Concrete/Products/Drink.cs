﻿using System;
using System.Collections.Generic;
using System.Text;
using VendingMachine.Core.Entities.Abstract;
using VendingMachine.Core.Entities.Concrete;
using VendingMachine.Domain.Concrete.Slots;

namespace VendingMachine.Domain.Concrete.Products
{
    public class Drink : ProductBase, IEntity
    {
        public virtual int ML { get; set; } = 0;

        public Drink()
        {

        }

        public Drink(int id, string name, double price, int quantity, int mL)
        {
            Id = id;
            Name = name;
            Price = price;
            Quantity = quantity;
            ML = mL;
        }
    }
}
