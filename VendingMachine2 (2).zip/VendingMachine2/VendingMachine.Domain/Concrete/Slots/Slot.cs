﻿using System;
using System.Collections.Generic;
using System.Text;
using VendingMachine.Core.Entities.Abstract;
using VendingMachine.Core.Entities.Concrete;
using VendingMachine.Domain.Concrete.Products;

namespace VendingMachine.Domain.Concrete.Slots
{
    public class Slot : EntityBase, IEntity
    {

        public virtual bool IsEmpty { get; set; }
        public Drink Drink { get; set; }
        public int DrinkId { get; set; } = 0;
        public Food Food { get; set; }
        public int FoodId { get; set; } = 0;
        //public int ProductId { get; set; }
        //public string ProductName { get; set; }

        public Slot()
        {

        }

        public Slot(int slotId, int drinkId, int foodId)
        {
            Id = slotId;
            DrinkId = drinkId;
            FoodId = foodId;

            IsEmpty = true;
        }


        /*public Slot(string str, int slotId, int productId)
        {
            if (str == "F")
            {
                Id = slotId;
                ProductId = productId;
                Food.Id = productId;
                ProductName = Food.Name;

                IsEmpty = false;
            } 
            else if (str == "D")
            {
                Id = slotId;
                ProductId = productId;
                Drink.Id = productId;
                ProductName = Drink.Name;

                IsEmpty = false;
            }
        }*/

        /*public Slot(int id)
        {
            Id = id;
            FoodId = 0;
            DrinkId = 0;
            IsEmpty = true;
        }*/
    }
}
