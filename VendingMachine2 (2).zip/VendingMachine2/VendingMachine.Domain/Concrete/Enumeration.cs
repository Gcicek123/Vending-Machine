﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VendingMachine.Domain.Concrete
{
    public class Enumeration : IComparable
    {
        public long Id { get; set; }
        public string Name { get; set; }

        public Enumeration()
        {

        }

        public Enumeration(long id, string name)
        {
            Id = id;
            Name = name;
        }

        public int CompareTo(object obj)
        {
            throw new NotImplementedException();
        }
    }
}
