﻿using System;
using System.Collections.Generic;
using System.Text;
using VendingMachine.Core.Data.Abstract;
using VendingMachine.Domain.Concrete.Slots;

namespace VendingMachine.Data.Abstract
{
    public interface ISlotRepository : IRepository<Slot>
    {
    }
}
