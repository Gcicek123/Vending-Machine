﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using VendingMachine.Core.Data.Abstract;

namespace VendingMachine.Data.Abstract
{
    public interface IUnitOfWork : IAsyncDisposable
    {
        IDrinkRepository Drinks { get; }
        IFoodRepository Foods { get; }

        Task<int> SaveAsync();
    }
}
