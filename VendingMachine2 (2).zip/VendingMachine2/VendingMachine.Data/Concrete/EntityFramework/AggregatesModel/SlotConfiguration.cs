﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;
using VendingMachine.Domain.Concrete.Products;
using VendingMachine.Domain.Concrete.Slots;

namespace VendingMachine.Data.Concrete.EntityFramework.AggregatesModel
{
    public class SlotConfiguration : IEntityTypeConfiguration<Slot>
    {
        public void Configure(EntityTypeBuilder<Slot> builder)
        {
            builder.ToTable("Slots");

            builder.HasKey(a => a.Id);
            builder.Property(a => a.Id).ValueGeneratedOnAdd();
            builder.Property(a => a.Id).IsRequired();

            builder.HasOne(a => a.Drink).WithMany().HasForeignKey(a => a.DrinkId);
            builder.HasOne(a => a.Food).WithMany().HasForeignKey(a => a.FoodId);

            builder.HasData(new Slot(1, 2, 3));
            builder.HasData(new Slot(2, 3, 1));
            builder.HasData(new Slot(3, 1, 2));
        }
    }
}
