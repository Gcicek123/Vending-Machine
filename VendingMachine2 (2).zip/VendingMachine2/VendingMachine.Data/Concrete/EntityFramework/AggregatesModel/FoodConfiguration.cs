﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;
using VendingMachine.Domain.Concrete.Products;
using VendingMachine.Domain.Concrete.Slots;

namespace VendingMachine.Data.Concrete.EntityFramework.AggregatesModel
{
    public class FoodConfiguration : IEntityTypeConfiguration<Food>
    {
        public void Configure(EntityTypeBuilder<Food> builder)
        {
            builder.ToTable("Foods");

            builder.HasKey(a => a.Id);
            builder.Property(a => a.Id).ValueGeneratedOnAdd();
            builder.Property(a => a.Id).IsRequired();
            builder.Property(a => a.Price).IsRequired();
            builder.Property(a => a.Quantity).IsRequired();
            builder.Property(a => a.Name).IsRequired().HasMaxLength(20);

            builder.HasData(new Food(1, "Biscuit", 3.25, 10, 100, true));
            builder.HasData(new Food(2, "Pretzel", 1.5, 5, 50, true));
            builder.HasData(new Food(3, "Brownie", 2, 8, 20, false));
            builder.HasData(new Food(4, "Chips", 2.5, 4, 50, false));
        }
    }
}
