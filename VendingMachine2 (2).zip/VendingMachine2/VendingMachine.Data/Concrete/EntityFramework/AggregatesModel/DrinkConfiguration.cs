﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;
using VendingMachine.Domain.Concrete.Products;
using VendingMachine.Domain.Concrete.Slots;

namespace VendingMachine.Data.Concrete.EntityFramework.AggregatesModel
{
    public class DrinkConfiguration : IEntityTypeConfiguration<Drink>
    {
        public void Configure(EntityTypeBuilder<Drink> builder)
        {
            builder.ToTable("Drinks");

            builder.HasKey(a => a.Id);
            builder.Property(a => a.Id).ValueGeneratedOnAdd();
            builder.Property(a => a.Id).IsRequired();
            builder.Property(a => a.Id).HasMaxLength(2);
            builder.Property(a => a.Price).IsRequired();
            builder.Property(a => a.Quantity).IsRequired();
            builder.Property(a => a.Name).IsRequired().HasMaxLength(20);
            
            builder.HasData(new Drink(1, "Coca Cola", 5, 5, 300));
            builder.HasData(new Drink(2, "Water", 3, 8, 500));
            builder.HasData(new Drink(3, "Orange Juice", 8, 4, 200));
        }
    }
}
