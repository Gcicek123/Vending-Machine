﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using VendingMachine.Data.Concrete.EntityFramework.AggregatesModel;
using VendingMachine.Domain.Concrete.Products;

namespace VendingMachine.Data.Concrete.EntityFramework.Contexts
{
    public class VendingMachineContext : DbContext
    {
        public DbSet<Food> Foods { get; set; }
        public DbSet<Drink> Drinks { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server = PARTTIME02-PC; Database = VendingMachine; Trusted_Connection = True; Connect Timeout = 30; MultipleActiveResultSets = True; ");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new DrinkConfiguration());
            modelBuilder.ApplyConfiguration(new FoodConfiguration());
            modelBuilder.ApplyConfiguration(new SlotConfiguration());
        }
    }

    
}
