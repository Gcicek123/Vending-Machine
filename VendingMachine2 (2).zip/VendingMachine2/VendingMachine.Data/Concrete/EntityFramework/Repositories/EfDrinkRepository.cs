﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using VendingMachine.Core.Data.Concrete;
using VendingMachine.Data.Abstract;
using VendingMachine.Domain.Concrete.Products;

namespace VendingMachine.Data.Concrete.EntityFramework.Repositories
{
    public class EfDrinkRepository : RepositoryBase<Drink>, IDrinkRepository
    {
        public EfDrinkRepository(DbContext context) : base(context)
        {

        }
    }
}
