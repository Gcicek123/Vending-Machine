﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using VendingMachine.Core.Data.Concrete;
using VendingMachine.Data.Abstract;
using VendingMachine.Domain.Concrete.Slots;

namespace VendingMachine.Data.Concrete.EntityFramework.Repositories
{
    public class EfSlotRepository : RepositoryBase<Slot>, ISlotRepository
    {
        public EfSlotRepository(DbContext context) : base(context)
        {

        }

    }
}
