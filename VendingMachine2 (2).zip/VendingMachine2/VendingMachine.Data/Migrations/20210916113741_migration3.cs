﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace VendingMachine.Data.Migrations
{
    public partial class migration3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Drinks",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", maxLength: 2, nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ML = table.Column<int>(type: "int", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ModifiedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    Price = table.Column<double>(type: "float", nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Drinks", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Foods",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Weight = table.Column<int>(type: "int", nullable: false),
                    GlutenFree = table.Column<bool>(type: "bit", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ModifiedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    Price = table.Column<double>(type: "float", nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Foods", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Slots",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IsEmpty = table.Column<bool>(type: "bit", nullable: false),
                    DrinkId = table.Column<int>(type: "int", nullable: false),
                    FoodId = table.Column<int>(type: "int", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ModifiedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Slots", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Slots_Drinks_DrinkId",
                        column: x => x.DrinkId,
                        principalTable: "Drinks",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Slots_Foods_FoodId",
                        column: x => x.FoodId,
                        principalTable: "Foods",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Drinks",
                columns: new[] { "Id", "CreatedDate", "IsDeleted", "ML", "ModifiedDate", "Name", "Price", "Quantity" },
                values: new object[,]
                {
                    { 1, new DateTime(2021, 9, 16, 14, 37, 41, 159, DateTimeKind.Local).AddTicks(4010), false, 300, new DateTime(2021, 9, 16, 14, 37, 41, 160, DateTimeKind.Local).AddTicks(7883), "Coca Cola", 5.0, 5 },
                    { 2, new DateTime(2021, 9, 16, 14, 37, 41, 162, DateTimeKind.Local).AddTicks(1217), false, 500, new DateTime(2021, 9, 16, 14, 37, 41, 162, DateTimeKind.Local).AddTicks(1226), "Water", 3.0, 8 },
                    { 3, new DateTime(2021, 9, 16, 14, 37, 41, 162, DateTimeKind.Local).AddTicks(1321), false, 200, new DateTime(2021, 9, 16, 14, 37, 41, 162, DateTimeKind.Local).AddTicks(1324), "Orange Juice", 8.0, 4 }
                });

            migrationBuilder.InsertData(
                table: "Foods",
                columns: new[] { "Id", "CreatedDate", "GlutenFree", "IsDeleted", "ModifiedDate", "Name", "Price", "Quantity", "Weight" },
                values: new object[,]
                {
                    { 1, new DateTime(2021, 9, 16, 14, 37, 41, 163, DateTimeKind.Local).AddTicks(6154), true, false, new DateTime(2021, 9, 16, 14, 37, 41, 163, DateTimeKind.Local).AddTicks(6162), "Biscuit", 3.25, 10, 100 },
                    { 2, new DateTime(2021, 9, 16, 14, 37, 41, 163, DateTimeKind.Local).AddTicks(7112), true, false, new DateTime(2021, 9, 16, 14, 37, 41, 163, DateTimeKind.Local).AddTicks(7118), "Pretzel", 1.5, 5, 50 },
                    { 3, new DateTime(2021, 9, 16, 14, 37, 41, 163, DateTimeKind.Local).AddTicks(7126), false, false, new DateTime(2021, 9, 16, 14, 37, 41, 163, DateTimeKind.Local).AddTicks(7128), "Brownie", 2.0, 8, 20 },
                    { 4, new DateTime(2021, 9, 16, 14, 37, 41, 163, DateTimeKind.Local).AddTicks(7131), false, false, new DateTime(2021, 9, 16, 14, 37, 41, 163, DateTimeKind.Local).AddTicks(7132), "Chips", 2.5, 4, 50 }
                });

            migrationBuilder.InsertData(
                table: "Slots",
                columns: new[] { "Id", "CreatedDate", "DrinkId", "FoodId", "IsDeleted", "IsEmpty", "ModifiedDate" },
                values: new object[] { 2, new DateTime(2021, 9, 16, 14, 37, 41, 301, DateTimeKind.Local).AddTicks(5594), 3, 1, false, true, new DateTime(2021, 9, 16, 14, 37, 41, 301, DateTimeKind.Local).AddTicks(5601) });

            migrationBuilder.InsertData(
                table: "Slots",
                columns: new[] { "Id", "CreatedDate", "DrinkId", "FoodId", "IsDeleted", "IsEmpty", "ModifiedDate" },
                values: new object[] { 3, new DateTime(2021, 9, 16, 14, 37, 41, 301, DateTimeKind.Local).AddTicks(5626), 1, 2, false, true, new DateTime(2021, 9, 16, 14, 37, 41, 301, DateTimeKind.Local).AddTicks(5628) });

            migrationBuilder.InsertData(
                table: "Slots",
                columns: new[] { "Id", "CreatedDate", "DrinkId", "FoodId", "IsDeleted", "IsEmpty", "ModifiedDate" },
                values: new object[] { 1, new DateTime(2021, 9, 16, 14, 37, 41, 301, DateTimeKind.Local).AddTicks(4300), 2, 3, false, true, new DateTime(2021, 9, 16, 14, 37, 41, 301, DateTimeKind.Local).AddTicks(4328) });

            migrationBuilder.CreateIndex(
                name: "IX_Slots_DrinkId",
                table: "Slots",
                column: "DrinkId");

            migrationBuilder.CreateIndex(
                name: "IX_Slots_FoodId",
                table: "Slots",
                column: "FoodId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Slots");

            migrationBuilder.DropTable(
                name: "Drinks");

            migrationBuilder.DropTable(
                name: "Foods");
        }
    }
}
